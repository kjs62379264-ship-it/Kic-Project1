from flask import Flask, render_template, request, redirect, url_for, flash, session, g
import sqlite3
from datetime import datetime, time
# ✨ [추가] 비밀번호 확인 및 해싱, 로그인 필요 데코레이터
from werkzeug.security import check_password_hash, generate_password_hash
import functools # 데코레이터 만들 때 필요

app = Flask(__name__)
app.secret_key = 'your_super_secret_key' # Flask 세션 기능을 위해 꼭 필요!

# ✨ [핵심 추가] 모든 요청 전에 실행되어, 로그인된 사용자 정보를 g 객체에 저장합니다.
@app.before_request
def load_logged_in_user():
    user_id = session.get('user_id') # 세션에서 user_id 가져오기
    if user_id is None:
        g.user = None # 로그인 안된 상태
    else:
        # DB에서 현재 로그인된 사용자 정보를 가져와 g.user에 저장
        conn = sqlite3.connect('employees.db')
        conn.row_factory = sqlite3.Row
        g.user = conn.execute('SELECT * FROM employees WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        # g 객체는 현재 요청 내에서 유지되는 전역 변수처럼 사용 가능

# ✨ [핵심 추가] 로그인이 필요한 함수 위에 @login_required를 붙여 사용합니다.
def login_required(view):
    @functools.wraps(view)
    def wrapped_view(**kwargs):
        if g.user is None:
            # 로그인되어 있지 않으면 로그인 페이지로 보냅니다.
            flash("로그인이 필요합니다.", "error") # 사용자에게 알림
            return redirect(url_for('login', next=request.url)) # 로그인 후 원래 가려던 페이지로 이동시키기 위해 next 파라미터 전달
        # 로그인되어 있으면 원래 함수를 실행합니다.
        return view(**kwargs)
    return wrapped_view

# ✨ [핵심 수정] 출퇴근 상태 확인 시 g.user (로그인된 사용자) 정보를 사용합니다.
@app.context_processor
def inject_attendance_status():
    if not g.user: # 로그인 안 했으면 아무것도 안 함
        return {} # 빈 딕셔너리 반환
        
    today = datetime.now().date()
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT clock_out_time FROM attendance 
        WHERE employee_id = ? AND record_date = ?
        ORDER BY id DESC LIMIT 1
    """, (g.user['id'], today)) # <-- g.user['id'] 사용
    last_record = cursor.fetchone()
    conn.close()

    button_state = '출근'
    if last_record and last_record['clock_out_time'] is None:
        button_state = '퇴근'
    # g.user 정보도 모든 템플릿에서 사용할 수 있도록 전달
    return dict(attendance_button_state=button_state, current_user=g.user)

# ✨ [추가] 로그인 페이지 라우트
@app.route('/login', methods=['GET', 'POST'])
def login():
    # 이미 로그인된 사용자는 메인 페이지로 보냄
    if g.user:
        return redirect(url_for('hr_management'))

    if request.method == 'POST':
        employee_id = request.form['employee_id']
        password = request.form['password']
        conn = sqlite3.connect('employees.db')
        conn.row_factory = sqlite3.Row
        error = None
        user = conn.execute('SELECT * FROM employees WHERE id = ?', (employee_id,)).fetchone()
        conn.close()

        if user is None:
            error = '사번 또는 비밀번호 오류입니다.'
        # DB에 저장된 해시된 비밀번호와 사용자가 입력한 비밀번호를 비교합니다.
        elif not check_password_hash(user['password'], password):
            error = '사번 또는 비밀번호 오류입니다.'
        elif user['status'] == '퇴사': # 퇴사한 직원은 로그인 불가
            error = '퇴사한 직원은 로그인할 수 없습니다.'

        if error is None:
            # 로그인 성공 시 세션에 사용자 ID 저장
            session.clear()
            session['user_id'] = user['id']
            # 로그인 후 이동할 페이지가 있으면 거기로, 없으면 대시보드로
            next_url = request.args.get('next')
            if next_url:
                return redirect(next_url)
            else:
                return redirect(url_for('hr_management'))
        
        flash(error, "error") # 로그인 실패 메시지 표시 (카테고리 지정)

    # GET 요청 시 로그인 폼 보여주기
    return render_template('login.html')

# ✨ [추가] 로그아웃 라우트
@app.route('/logout')
def logout():
    session.clear() # 세션 정보 삭제
    return redirect(url_for('login')) # 로그인 페이지로 이동


# ✨ [핵심 수정] 출퇴근 기록 시 g.user['id'] 사용
@app.route('/attendance/clock', methods=['POST'])
@login_required # 로그인이 필요합니다.
def clock():
    now = datetime.now()
    today = now.date()
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT id, clock_out_time FROM attendance 
        WHERE employee_id = ? AND record_date = ?
        ORDER BY id DESC LIMIT 1
    """, (g.user['id'], today)) # <-- g.user['id'] 사용
    last_record = cursor.fetchone()
    if last_record and last_record['clock_out_time'] is None:
        cursor.execute("UPDATE attendance SET clock_out_time = ? WHERE id = ?", (now, last_record['id']))
    else:
        status = '정상'
        # 첫 출근 시각이 9시 1분 이후면 지각 처리 (9:00:59 초과)
        if not last_record and now.time() > time(9, 0, 59):
             status = '지각'
        cursor.execute("""
            INSERT INTO attendance (employee_id, record_date, clock_in_time, attendance_status)
            VALUES (?, ?, ?, ?)
        """, (g.user['id'], today, now, status)) # <-- g.user['id'] 사용
    conn.commit()
    conn.close()
    return redirect(request.referrer or url_for('hr_management'))

# ✨ [핵심 수정] 내 출퇴근 기록 조회 시 g.user['id'] 사용
@app.route('/my_attendance')
@login_required # 로그인이 필요합니다.
def my_attendance():
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("""
        SELECT record_date, clock_in_time, clock_out_time, attendance_status
        FROM attendance
        WHERE employee_id = ?
        ORDER BY record_date DESC, clock_in_time DESC
    """, (g.user['id'],)) # <-- g.user['id'] 사용
    attendance_records = cursor.fetchall()
    conn.close()
    return render_template('my_attendance.html', records=attendance_records)

@app.route('/')
@app.route('/hr')
@login_required # 로그인이 필요합니다.
def hr_management():
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    id_query = request.args.get('id', '')
    name_query = request.args.get('name', '')
    department_query = request.args.get('department', '')
    position_query = request.args.get('position', '')
    gender_query = request.args.get('gender', '')
    status_query = request.args.get('status', '재직')
    
    base_sql = "SELECT * FROM employees"
    where_clauses = []
    params = []
    if id_query: where_clauses.append("id LIKE ?"); params.append(f"%{id_query}%")
    if name_query: where_clauses.append("name LIKE ?"); params.append(f"%{name_query}%")
    if department_query: where_clauses.append("department = ?"); params.append(department_query)
    if position_query: where_clauses.append("position = ?"); params.append(position_query)
    if gender_query: where_clauses.append("gender = ?"); params.append(gender_query)
    if status_query and status_query != '전체': where_clauses.append("status = ?"); params.append(status_query)
    
    sql = base_sql
    if where_clauses: sql += " WHERE " + " AND ".join(where_clauses)
    sql += " ORDER BY id DESC" # 기본 정렬은 그대로 유지
    cursor.execute(sql, tuple(params))
    employee_list = cursor.fetchall()
    employee_count = len(employee_list)
    
    cursor.execute("SELECT name, code FROM departments ORDER BY name")
    departments = cursor.fetchall()
    cursor.execute("SELECT name FROM positions ORDER BY name")
    positions = cursor.fetchall()
    cursor.execute("SELECT department, COUNT(*) as count FROM employees WHERE status = '재직' GROUP BY department ORDER BY count DESC")
    dept_stats = cursor.fetchall()
    dept_labels = [row['department'] for row in dept_stats]
    dept_counts = [row['count'] for row in dept_stats]
    cursor.execute("SELECT id, title, content, created_at FROM notices ORDER BY created_at DESC LIMIT 5")
    notices = cursor.fetchall()
    conn.close()
    return render_template('hr_management.html', 
                           employees=employee_list, departments=departments, positions=positions,
                           employee_count=employee_count, dept_labels=dept_labels,
                           dept_counts=dept_counts, notices=notices)

@app.route('/hr/add', methods=['GET', 'POST'])
@login_required # 로그인이 필요합니다.
def add_employee():
    # ✨ [추가] 관리자만 접근 가능하도록 권한 확인
    if g.user['role'] != 'admin':
        flash("관리자만 직원을 추가할 수 있습니다.", "error")
        return redirect(url_for('hr_management'))
        
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        position = request.form['position']
        hire_date = request.form['hire_date']
        phone_number = f"{request.form['phone1']}-{request.form['phone2']}-{request.form['phone3']}"
        email = f"{request.form['email_id']}@{request.form['email_domain']}"
        address = request.form['address']
        gender = request.form['gender']
        # ✨ [수정] 기본 비밀번호('1234')와 역할을 폼에서 받거나 기본값 설정
        password = generate_password_hash(request.form.get('password', '1234')) # 기본 비번 '1234'
        role = request.form.get('role', 'user') # 기본 역할 'user'

        cursor.execute("SELECT code FROM departments WHERE name = ?", (department,))
        dept_code_row = cursor.fetchone()
        dept_code = dept_code_row[0] if dept_code_row else 'XX'
        year_prefix = hire_date.split('-')[0][2:]
        prefix = year_prefix + dept_code
        cursor.execute("SELECT id FROM employees WHERE id LIKE ? ORDER BY id DESC LIMIT 1", (prefix + '%',))
        last_id = cursor.fetchone()
        new_seq = int(last_id[0][-4:]) + 1 if last_id else 1
        new_id = f"{prefix}{new_seq:04d}"

        # ✨ [수정] INSERT 시 password, role 포함
        cursor.execute("""
            INSERT INTO employees (id, name, password, department, position, hire_date, phone_number, email, address, gender, status, role) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '재직', ?)
        """, (new_id, name, password, department, position, hire_date, phone_number, email, address, gender, role))
        conn.commit()
        conn.close()
        flash(f"{name} 직원이 성공적으로 등록되었습니다.", "success")
        return redirect(url_for('hr_management'))

    # GET 요청 시 필요한 데이터 로드
    cursor.execute("SELECT name FROM departments ORDER BY name")
    departments = cursor.fetchall()
    cursor.execute("SELECT name FROM positions ORDER BY name")
    positions = cursor.fetchall()
    cursor.execute("SELECT domain FROM email_domains ORDER BY domain")
    email_domains = cursor.fetchall()
    conn.close()
    return render_template('add_employee.html', departments=departments, positions=positions, email_domains=email_domains)

@app.route('/hr/employee/<employee_id>')
@login_required # 로그인이 필요합니다.
def employee_detail(employee_id):
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM employees WHERE id = ?", (employee_id,))
    employee = cursor.fetchone() 
    conn.close()
    if employee is None:
        flash("해당 직원을 찾을 수 없습니다.", "error")
        return redirect(url_for('hr_management'))
    return render_template('employee_detail.html', employee=employee)

@app.route('/hr/edit/<employee_id>', methods=['GET', 'POST'])
@login_required # 로그인이 필요합니다.
def edit_employee(employee_id):
    # ✨ [추가] 관리자 또는 본인만 수정 가능
    if g.user['role'] != 'admin' and g.user['id'] != employee_id:
        flash("수정 권한이 없습니다.", "error")
        # 본인이면 상세페이지로, 관리자가 아니면서 남의 정보 수정 시도시 목록으로
        if g.user['id'] == employee_id:
             return redirect(url_for('employee_detail', employee_id=employee_id))
        else:
             return redirect(url_for('hr_management'))

    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if request.method == 'POST':
        name = request.form['name']
        department = request.form['department']
        position = request.form['position']
        hire_date = request.form['hire_date']
        phone_number = f"{request.form['phone1']}-{request.form['phone2']}-{request.form['phone3']}"
        email = f"{request.form['email_id']}@{request.form['email_domain']}"
        address = request.form['address']
        gender = request.form['gender']
        # ✨ [추가] 역할(role) 수정 기능 (관리자만 가능)
        role = request.form.get('role', None)

        update_sql = """
            UPDATE employees SET name=?, department=?, position=?, hire_date=?, phone_number=?, email=?, address=?, gender=?
        """
        params = [name, department, position, hire_date, phone_number, email, address, gender]
        
        # 관리자이고 role 값이 넘어왔을 때만 role 업데이트
        if g.user['role'] == 'admin' and role:
            update_sql += ", role=?"
            params.append(role)
            
        update_sql += " WHERE id=?"
        params.append(employee_id)
        
        cursor.execute(update_sql, tuple(params))
        
        conn.commit()
        conn.close()
        flash("직원 정보가 성공적으로 수정되었습니다.", "success")
        return redirect(url_for('employee_detail', employee_id=employee_id))

    # GET 요청: 수정할 직원 정보 로드
    cursor.execute("SELECT * FROM employees WHERE id = ?", (employee_id,))
    employee = cursor.fetchone()
    if employee is None:
        flash("해당 직원을 찾을 수 없습니다.", "error")
        conn.close()
        return redirect(url_for('hr_management'))
        
    cursor.execute("SELECT name FROM departments ORDER BY name")
    departments = cursor.fetchall()
    cursor.execute("SELECT name FROM positions ORDER BY name")
    positions = cursor.fetchall()
    cursor.execute("SELECT domain FROM email_domains ORDER BY domain")
    email_domains = cursor.fetchall()
    conn.close()

    phone_parts = employee['phone_number'].split('-') if employee and employee['phone_number'] else ['','','']
    email_parts = employee['email'].split('@') if employee and employee['email'] else ['','']

    return render_template('edit_employee.html', 
                           employee=employee, departments=departments, positions=positions, 
                           email_domains=email_domains, phone_parts=phone_parts,
                           email_parts=email_parts)

@app.route('/hr/print')
@login_required # 로그인이 필요합니다.
def print_employees():
    id_query = request.args.get('id', '')
    name_query = request.args.get('name', '')
    department_query = request.args.get('department', '')
    position_query = request.args.get('position', '')
    gender_query = request.args.get('gender', '')
    status_query = request.args.get('status', '재직')
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    base_sql = "SELECT * FROM employees"
    where_clauses = []
    params = []
    if id_query: where_clauses.append("id LIKE ?"); params.append('%' + id_query + '%')
    if name_query: where_clauses.append("name LIKE ?"); params.append('%' + name_query + '%')
    if department_query: where_clauses.append("department = ?"); params.append(department_query)
    if position_query: where_clauses.append("position = ?"); params.append(position_query)
    if gender_query: where_clauses.append("gender = ?"); params.append(gender_query)
    if status_query and status_query != '전체': where_clauses.append("status = ?"); params.append(status_query)
    sql = base_sql
    if where_clauses: sql += " WHERE " + " AND ".join(where_clauses)
    sql += " ORDER BY id DESC"
    cursor.execute(sql, tuple(params))
    employee_list = cursor.fetchall()
    conn.close()
    return render_template('print.html', employees=employee_list)

@app.route('/hr/depart/<employee_id>', methods=['POST'])
@login_required # 로그인이 필요합니다.
def process_departure(employee_id):
    # ✨ [추가] 관리자만 퇴사 처리 가능
    if g.user['role'] != 'admin':
        flash("퇴사 처리는 관리자만 가능합니다.", "error")
        return redirect(url_for('employee_detail', employee_id=employee_id))
        
    conn = sqlite3.connect('employees.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE employees SET status = '퇴사' WHERE id = ?", (employee_id,))
    conn.commit()
    conn.close()
    flash(f"직원({employee_id})이 퇴사 처리되었습니다.", "success")
    return redirect(url_for('employee_detail', employee_id=employee_id))
    
@app.route('/hr/rehire/<employee_id>', methods=['POST'])
@login_required # 로그인이 필요합니다.
def process_rehire(employee_id):
     # ✨ [추가] 관리자만 재입사 처리 가능
    if g.user['role'] != 'admin':
        flash("재입사 처리는 관리자만 가능합니다.", "error")
        return redirect(url_for('employee_detail', employee_id=employee_id))
        
    conn = sqlite3.connect('employees.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE employees SET status = '재직' WHERE id = ?", (employee_id,))
    conn.commit()
    conn.close()
    flash(f"직원({employee_id})이 재입사 처리되었습니다.", "success")
    return redirect(url_for('employee_detail', employee_id=employee_id))

@app.route('/hr/settings')
@login_required # 로그인이 필요합니다.
def settings_management():
    # ✨ [추가] 관리자만 접근 가능
    if g.user['role'] != 'admin':
        flash("설정 관리는 관리자만 접근 가능합니다.", "error")
        return redirect(url_for('hr_management'))
        
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM departments ORDER BY name")
    departments = cursor.fetchall()
    cursor.execute("SELECT * FROM positions ORDER BY name")
    positions = cursor.fetchall()
    conn.close()
    return render_template('settings_management.html', departments=departments, positions=positions)

@app.route('/hr/settings/add_department', methods=['POST'])
@login_required # 로그인이 필요합니다.
def add_department():
    # ✨ [추가] 관리자 권한 확인
    if g.user['role'] != 'admin': return redirect(url_for('hr_management')) 
    
    new_dept_name = request.form['new_department_name'].strip()
    new_dept_code = request.form['new_department_code'].strip().upper()
    if new_dept_name and new_dept_code:
        try:
            conn = sqlite3.connect('employees.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO departments (name, code) VALUES (?, ?)", (new_dept_name, new_dept_code))
            conn.commit()
            flash(f"'{new_dept_name}' 부서가 성공적으로 추가되었습니다.", "success")
        except sqlite3.IntegrityError:
            flash("이미 존재하거나 중복된 부서명 또는 코드입니다.", "error")
        finally:
            conn.close()
    return redirect(url_for('settings_management'))

@app.route('/hr/settings/add_position', methods=['POST'])
@login_required # 로그인이 필요합니다.
def add_position():
    # ✨ [추가] 관리자 권한 확인
    if g.user['role'] != 'admin': return redirect(url_for('hr_management'))
    
    new_pos_name = request.form['new_position'].strip()
    if new_pos_name:
        try:
            conn = sqlite3.connect('employees.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO positions (name) VALUES (?)", (new_pos_name,))
            conn.commit()
            flash(f"'{new_pos_name}' 직급이 성공적으로 추가되었습니다.", "success")
        except sqlite3.IntegrityError:
            flash("이미 존재하는 직급입니다.", "error")
        finally:
            conn.close()
    return redirect(url_for('settings_management'))

@app.route('/hr/settings/delete_department/<dept_name>', methods=['POST'])
@login_required # 로그인이 필요합니다.
def delete_department(dept_name):
    # ✨ [추가] 관리자 권한 확인
    if g.user['role'] != 'admin': return redirect(url_for('settings_management'))
    
    conn = sqlite3.connect('employees.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM employees WHERE department = ? AND status = '재직'", (dept_name,))
    employee_count = cursor.fetchone()[0]
    if employee_count > 0:
        flash(f"'{dept_name}' 부서에 재직 중인 직원이 있어 삭제할 수 없습니다.", "error")
    else:
        cursor.execute("DELETE FROM departments WHERE name = ?", (dept_name,))
        conn.commit()
        flash(f"'{dept_name}' 부서가 성공적으로 삭제되었습니다.", "success")
    conn.close()
    return redirect(url_for('settings_management'))

@app.route('/hr/settings/delete_position/<pos_name>', methods=['POST'])
@login_required # 로그인이 필요합니다.
def delete_position(pos_name):
    # ✨ [추가] 관리자 권한 확인
    if g.user['role'] != 'admin': return redirect(url_for('settings_management'))
    
    conn = sqlite3.connect('employees.db')
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM employees WHERE position = ? AND status = '재직'", (pos_name,))
    employee_count = cursor.fetchone()[0]
    if employee_count > 0:
        flash(f"'{pos_name}' 직급에 재직 중인 직원이 있어 삭제할 수 없습니다.", "error")
    else:
        cursor.execute("DELETE FROM positions WHERE name = ?", (pos_name,))
        conn.commit()
        flash(f"'{pos_name}' 직급이 성공적으로 삭제되었습니다.", "success")
    conn.close()
    return redirect(url_for('settings_management'))

@app.route('/hr/settings/edit_department', methods=['POST'])
@login_required # 로그인이 필요합니다.
def edit_department():
    # ✨ [추가] 관리자 권한 확인
    if g.user['role'] != 'admin': return redirect(url_for('settings_management'))
    
    original_name = request.form['original_dept_name']
    new_name = request.form['new_dept_name'].strip()
    new_code = request.form['new_department_code'].strip().upper()
    try:
        conn = sqlite3.connect('employees.db')
        cursor = conn.cursor()
        cursor.execute("UPDATE departments SET name = ?, code = ? WHERE name = ?", (new_name, new_code, original_name))
        cursor.execute("UPDATE employees SET department = ? WHERE department = ?", (new_name, original_name))
        conn.commit()
        flash("부서 정보가 성공적으로 수정되었습니다.", "success")
    except sqlite3.IntegrityError:
        flash("이미 존재하거나 중복된 부서명 또는 코드입니다.", "error")
    finally:
        conn.close()
    return redirect(url_for('settings_management'))
    
# --- 공지사항 관련 라우트 ---
@app.route('/hr/notices/new', methods=['GET', 'POST'])
@login_required # 로그인이 필요합니다.
def add_notice_page():
    # ✨ [추가] 관리자만 공지 작성 가능
    if g.user['role'] != 'admin':
        flash("관리자만 공지사항을 작성할 수 있습니다.", "error")
        return redirect(url_for('hr_management'))
        
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        if title and content:
            conn = sqlite3.connect('employees.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO notices (title, content) VALUES (?, ?)", (title, content))
            conn.commit()
            conn.close()
            flash("새 공지사항이 등록되었습니다.", "success")
            return redirect(url_for('hr_management'))
    return render_template('add_notice_page.html')

@app.route('/hr/notices/<int:notice_id>')
@login_required # 로그인이 필요합니다.
def view_notice(notice_id):
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM notices WHERE id = ?", (notice_id,))
    notice = cursor.fetchone()
    conn.close()
    if notice is None:
        flash("해당 공지사항을 찾을 수 없습니다.", "error")
        return redirect(url_for('hr_management'))
    return render_template('notice_detail.html', notice=notice)

@app.route('/hr/notices/edit/<int:notice_id>', methods=['GET', 'POST'])
@login_required # 로그인이 필요합니다.
def edit_notice(notice_id):
    # ✨ [추가] 관리자만 수정 가능
    if g.user['role'] != 'admin':
        flash("관리자만 공지사항을 수정할 수 있습니다.", "error")
        return redirect(url_for('view_notice', notice_id=notice_id))
        
    conn = sqlite3.connect('employees.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        if title and content:
            cursor.execute("UPDATE notices SET title = ?, content = ? WHERE id = ?", (title, content, notice_id))
            conn.commit()
            conn.close()
            flash("공지사항이 성공적으로 수정되었습니다.", "success")
            return redirect(url_for('view_notice', notice_id=notice_id))
        else:
            flash("제목과 내용을 모두 입력해주세요.", "error")
            conn.close()
            return redirect(url_for('edit_notice', notice_id=notice_id)) 

    cursor.execute("SELECT * FROM notices WHERE id = ?", (notice_id,))
    notice = cursor.fetchone()
    conn.close()
    if notice is None:
        flash("수정할 공지사항을 찾을 수 없습니다.", "error")
        return redirect(url_for('hr_management'))
    return render_template('edit_notice_page.html', notice=notice)

@app.route('/hr/notices/delete/<int:notice_id>', methods=['POST'])
@login_required # 로그인이 필요합니다.
def delete_notice(notice_id):
    # ✨ [추가] 관리자만 삭제 가능
    if g.user['role'] != 'admin':
        flash("관리자만 공지사항을 삭제할 수 있습니다.", "error")
        return redirect(url_for('hr_management'))
        
    conn = sqlite3.connect('employees.db')
    cursor = conn.cursor()
    cursor.execute("DELETE FROM notices WHERE id = ?", (notice_id,))
    conn.commit()
    conn.close()
    flash("공지사항이 삭제되었습니다.", "success")
    return redirect(url_for('hr_management'))

# --- 앱 실행 ---
if __name__ == '__main__':
    app.run(debug=True)