import sqlite3
# ✨ [추가] 비밀번호 해싱을 위한 라이브러리
from werkzeug.security import generate_password_hash

conn = sqlite3.connect('employees.db')
cursor = conn.cursor()

# --- 기존 테이블 삭제 ---
cursor.execute("DROP TABLE IF EXISTS employees")
cursor.execute("DROP TABLE IF EXISTS departments")
cursor.execute("DROP TABLE IF EXISTS positions")
cursor.execute("DROP TABLE IF EXISTS email_domains")
cursor.execute("DROP TABLE IF EXISTS attendance")
cursor.execute("DROP TABLE IF EXISTS notices")

# --- 테이블 생성 ---
cursor.execute("CREATE TABLE departments (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, code TEXT UNIQUE NOT NULL);")
cursor.execute("CREATE TABLE positions (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);")
cursor.execute("CREATE TABLE email_domains (id INTEGER PRIMARY KEY, domain TEXT UNIQUE NOT NULL);")

# ✨ [핵심 수정] employees 테이블에 password(해싱됨), role, profile_image 컬럼 추가
cursor.execute("""
CREATE TABLE employees (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    password TEXT NOT NULL,
    department TEXT NOT NULL,
    position TEXT NOT NULL,
    hire_date DATE NOT NULL,
    phone_number TEXT,
    email TEXT,
    address TEXT,
    gender TEXT,
    status TEXT DEFAULT '재직' NOT NULL,
    role TEXT DEFAULT 'user' NOT NULL,
    profile_image TEXT
);
""")

cursor.execute("""
CREATE TABLE attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT NOT NULL, record_date DATE NOT NULL,
    clock_in_time DATETIME, clock_out_time DATETIME, attendance_status TEXT,
    FOREIGN KEY (employee_id) REFERENCES employees (id)
);
""")
cursor.execute("""
CREATE TABLE notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
""")
print("All tables created.")

# --- 초기 데이터 삽입 ---
cursor.executemany("INSERT INTO departments (name, code) VALUES (?, ?)", [('인사팀', 'HR'), ('개발팀', 'DV'), ('디자인팀', 'DS'), ('마케팅팀', 'MK')])
cursor.executemany("INSERT INTO positions (name) VALUES (?)", [('사원',), ('주임',), ('대리',), ('과장',), ('팀장',)])
cursor.executemany("INSERT INTO email_domains (domain) VALUES (?)", [('company.com',), ('gmail.com',), ('naver.com',)])

# ✨ [핵심 수정] 초기 직원 데이터에 해싱된 비밀번호('1234'), 역할('admin'), 프로필 이미지 추가
cursor.execute("""
    INSERT INTO employees (id, name, password, department, position, hire_date, role, profile_image) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", ('25HR0001', '홍길동', generate_password_hash('1234'), '인사팀', '과장', '2025-01-10', 'admin', 'profile_1.jpg'))

cursor.execute("""
    INSERT INTO employees (id, name, password, department, position, hire_date, role, profile_image) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", ('25DV0001', '김개발', generate_password_hash('1234'), '개발팀', '대리', '2025-03-15', 'user', 'profile_2.jpg'))

# (퇴사자 데이터는 비밀번호, 역할 없이 그대로 둡니다)
cursor.execute("""
    INSERT INTO employees (id, name, password, department, position, hire_date, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
""", ('24DS0001', '이나영', generate_password_hash('1234'), '디자인팀', '주임', '2024-08-20', '퇴사'))

cursor.executemany("INSERT INTO notices (title, content) VALUES (?, ?)", [
    ('하반기 워크샵 장소 투표', '워크샵 장소 선정을 위한 투표를 10월 25일까지 진행합니다.'),
    ('건강검진 대상자 안내', '올해 건강검진 대상자 명단을 확인하시고, 11월까지 검진을 완료해주시기 바랍니다.'),
    ('사내 소방 안전 교육 실시', '10월 30일 오후 2시, 전 직원을 대상으로 소방 안전 교육이 있습니다.')
])
print("Initial data inserted.")

conn.commit()
conn.close()